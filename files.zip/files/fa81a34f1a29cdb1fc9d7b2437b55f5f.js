require([
    'tinyMCE'
], function(tinyMCE) {
    tinyMCE.addI18n({
        fr:{
            common:{
                edit_confirm:"Voulez-vous utiliser le mode WYSIWYG pour cette zone de texte\u00A0?",
                apply:"Appliquer",
                insert:"Ins\u00E9rer",
                update:"Mettre \u00E0 jour",
                cancel:"Annuler",
                close:"Fermer",
                browse:"Naviguer",
                class_name:"Classe",
                not_set:"-- Non init. --",
                clipboard_msg:"Copier/Couper/Coller n'est pas disponible sous Mozilla et sous Firefox.\nVoulez-vous plus d'information sur ce probl\u00E8me\u00A0?",
                clipboard_no_support:"Actuellement non support\u00E9 par votre navigateur, utilisez les raccourcis clavier \u00E0 ma place.",
                popup_blocked:"D\u00E9sol\u00E9, nous avons d\u00E9tect\u00E9 que votre bloqueur de popup a bloqu\u00E9 une fen\u00EAtre dont l'application a besoin. Vous devez d\u00E9sactiver votre bloqueur de popup pour pouvoir utiliser cet outil.",
                invalid_data:"Erreur : Valeurs incorrectes entr\u00E9es, elles sont marqu\u00E9es en rouge.",
                more_colors:"Plus de couleurs"
            },
            contextmenu:{
                align:"Alignement",
                left:"Gauche",
                center:"Centr\u00E9",
                right:"Droite",
                full:"Justifi\u00E9"
            },
            insertdatetime:{
                date_fmt:"%d-%m-%Y",
                time_fmt:"%H:%M:%S",
                insertdate_desc:"Ins\u00E9rer date",
                inserttime_desc:"Ins\u00E9rer heure",
                months_long:"Janvier,F\u00E9vrier,Mars,Avril,Mai,Juin,Juillet,Ao\u00FBt,Septembre,Octobre,Novembre,D\u00E9cembre",
                months_short:"Jan,F\u00E9v,Mar,Avr,Mai,Juin,Juil,Ao\u00FBt,Sep,Oct,Nov,D\u00E9c",
                day_long:"Dimanche,Lundi,Mardi,Mercredi,Jeudi,Vendredi,Samedi,Dimanche",
                day_short:"Dim,Lun,Mar,Mer,Jeu,Ven,Sam,Dim"
            },
            print:{
                print_desc:"Imprimer"
            },
            preview:{
                preview_desc:"Pr\u00E9visualiser"
            },
            directionality:{
                ltr_desc:"\u00C9criture de gauche \u00E0 droite",
                rtl_desc:"\u00C9criture de droite \u00E0 gauche"
            },
            layer:{
                insertlayer_desc:"Ins\u00E9rer une nouvelle couche",
                forward_desc:"D\u00E9placer vers l'avant",
                backward_desc:"D\u00E9placer vers l'arri\u00E8re",
                absolute_desc:"Activer le positionnement absolu",
                content:"Nouvelle couche..."
            },
            save:{
                save_desc:"Sauver",
                cancel_desc:"Annuler tous les changements"
            },
            nonbreaking:{
                nonbreaking_desc:"Ins\u00E9rer un espace ins\u00E9cable"
            },
            advhr:{
                advhr_desc:"Ins\u00E9rer trait horizontal"
            },
            emotions:{
                emotions_desc:"\u00C9motions"
            },
            searchreplace:{
                search_desc:"Chercher",
                replace_desc:"Chercher/Remplacer"
            },
            advimage:{
                image_desc:"Ins\u00E9rer/\u00C9diter image"
            },
            advlink:{
                link_desc:"Ins\u00E9rer/\u00C9diter lien"
            },
            xhtmlxtras:{
                cite_desc:"Citation",
                abbr_desc:"Abr\u00E9viation",
                acronym_desc:"Acronyme",
                del_desc:"Effacement",
                ins_desc:"Insertion",
                attribs_desc:"Ins\u00E9rer/\u00C9diter les attributs"
            },
            style:{
                desc:"\u00C9diter la feuille de style CSS"
            },
            paste:{
                paste_text_desc:"Coller en tant que texte brut",
                paste_word_desc:"Coller \u00E0 partir d'un texte cr\u00E9\u00E9 sous Word",
                selectall_desc:"S\u00E9lectioner tout"
            },
            paste_dlg:{
                text_title:"Utilisez CTRL+V sur votre clavier pour coller le texte dans la fen\u00EAtre.",
                text_linebreaks:"Conserver les sauts de ligne",
                word_title:"Utilisez CTRL+V sur votre clavier pour coller le texte dans la fen\u00EAtre."
            },
            table:{
                desc:"Ins\u00E9rer un nouveau tableau",
                row_before_desc:"Ins\u00E9rer ligne avant",
                row_after_desc:"Ins\u00E9rer ligne apr\u00E8s",
                delete_row_desc:"Effacer ligne",
                col_before_desc:"Ins\u00E9rer colonne avant",
                col_after_desc:"Ins\u00E9rer colonne apr\u00E8s",
                delete_col_desc:"Effacer colonne",
                split_cells_desc:"Scinder les cellules fusionn\u00E9es",
                merge_cells_desc:"Fusionner les cellules",
                row_desc:"Propri\u00E9t\u00E9s de la ligne",
                cell_desc:"Propri\u00E9t\u00E9s de la cellule",
                props_desc:"Propri\u00E9t\u00E9s du tableau",
                paste_row_before_desc:"Coller la ligne avant",
                paste_row_after_desc:"Coller la ligne apr\u00E8s",
                cut_row_desc:"Couper la ligne",
                copy_row_desc:"Copier la ligne",
                del:"Effacer tableau",
                row:"Ligne",
                col:"Colonne",
                cell:"Cellule"
            },
            autosave:{
                unload_msg:"Les changements que vous avez faits seront perdus si vous changez de page."
            },
            fullscreen:{
                desc:"Passer en mode plein \u00E9cran"
            },
            media:{
                desc:"Ins\u00E9rer/\u00C9diter un fichier m\u00E9dia",
                edit:"\u00C9diter un fichier m\u00E9dia"
            },
            fullpage:{
                desc:"Propri\u00E9t\u00E9s du document"
            },
            template:{
                desc:"Ins\u00E9rer un mod\u00E8le pr\u00E9d\u00E9fini."
            },
            visualchars:{
                desc:"Activer les caract\u00E8res de mise en page."
            },
            spellchecker:{
                desc:"Activer le v\u00E9rificateur d'orthographe",
                menu:"Param\u00E8tres du v\u00E9rificateur d'orthographe",
                ignore_word:"Ignorer mot",
                ignore_words:"Ignorer tout",
                langs:"Langues",
                wait:"Patientez svp...",
                sug:"Suggestions",
                no_sug:"Aucune suggestions",
                no_mpell:"Aucune erreur trouv\u00E9e."
            },
            pagebreak:{
                desc:"Ins\u00E9rer saut de page."
            }
        }
    });
});

;
require([
    'tinyMCE'
], function(tinyMCE) {
    tinyMCE.addI18n('fr.table',{
        desc:"Insérer un tableau",
        row_up:"Déplacer la ligne vers le haut",
        row_down:"Déplacer la ligne vers le bas",
        col_left:"Déplacer la colonne vers la gauche",
        col_right:"Déplacer la colonne vers la droite"
    });
    tinyMCE.addI18n('fr.common',{
        edit_confirm:"Voulez-vous utiliser le mode WYSIWYG pour ce formulaire ?",
        apply:"Appliquer",
        insert:"Insérer",
        update:"Mettre à jour",
        cancel:"Annuler",
        close:"Fermer",
        browse:"Parcourir",
        class_name:"Classe",
        not_set:"— Non défini —",
        clipboard_msg:"Les fonctions Couper/Copier/Coller ne sont pas disponibles dans Mozilla ni Firefox. Souhaitez-vous plus de renseignements à propos de ce problème ?",
        clipboard_no_support:"Fonction non prise en charge par votre navigateur ; utilisez plutôt les raccourcis clavier.",
        popup_blocked:"Désolés, mais nous avons remarqué que votre logiciel anti-popup a désactivé une fenêtre qui fournit une fonctionnalité de l’application. Vous devez désactiver le logiciel anti-popup pour pouvoir utiliser pleinement cet outil.",
        invalid_data:"Erreur : valeurs saisies non valides (en rouge).",
        more_colors:"Autres couleurs",
        close_modal:"Fermer la fenêtre contextuelle"
    });
    tinyMCE.addI18n('fr.spellchecker',{
        desc:"Activer/désactiver le correcteur d\'\'orthographe",
        menu:"Paramètres du correcteur d\'\'orthographe",
        ignore_word:"Ignorer le mot",
        ignore_words:"Tout ignorer",
        langs:"Langues",
        wait:"Veuillez patienter…",
        sug:"Suggestions",
        no_sug:"Aucune suggestion",
        no_mpell:"Aucune erreur trouvée.",
        learn_word:"Ajouter au dictionnaire"
    });
    tinyMCE.addI18n('fr.aria', {
        rich_text_area: "Zone de texte enrichi."
    });
});

;
require([
    'tinyMCE'
], function(tinyMCE) {
    tinyMCE.addI18n('fr.jivelists',{
        list_style : 'Style de liste',
        list_style_hdr : 'Style de liste :',
        inherit : "Hériter de",
        none : "Aucun",
        'default' : "Par défaut",
        ur : "Upper Roman",
        lr : "Lower Roman",
        dz : "Décimal avec zéro non significatif",
        d  : "Décimale",
        ua : "Alpha majuscules",
        la : "Alpha minuscules",
        lg : "Grecques minuscules",
        ki : "Katakana-Iroha",
        hii: "Hiragana-Iroha",
        k  : "Katakana",
        hi : "Hiragana",
        ci : "Cjk-Ideographique",
        g  : "Géorgien",
        a  : "Arménien",
        he : "Hébreu",
        s  : "Carrés",
        c  : "Cercles",
        di : "Disques"
    });
});

;
require([
    'tinyMCE'
], function(tinyMCE) {
    tinyMCE.addI18n('fr.jivestyle',{
        title : 'Style',
        paragraph : 'Paragraphe',
        header : 'En-tête'
    });
});

;
require([
    'tinyMCE'
], function(tinyMCE) {
    tinyMCE.addI18n('fr.jivemacros',{
        unlink : "Annuler le lien",
        add : 'Insérer',
        remove : 'Supprimer',
        unquote : 'Annuler la citation',
        properties : 'Paramètres',
        title : 'Paramètres',
        presets : 'Valeurs prédéfinies',
        save: "Enregistrer",
        params : 'Paramètres',
        'macro.toc': "Table des matières",
        'macro.quote': "Citation",
        'macro.user': "Utilisateur",
        'macro.youtube': "YouTube",
        'macro.youtube.attr.__default_attr': "URL ou identifiant de vidéo",
        'macro.youtube.attr.width': "Largeur",
        'macro.youtube.attr.height': "Hauteur",
        'macro.code': "Mise en surbrillance de la syntaxe",
        'macro.code.presets': "Mise en forme",
        'macro.code.attr.__default_attr': "Mise en forme",
        'macro.code.preset.plain': "Normal",
        'macro.code.preset.sql': "SQL",
        'macro.code.preset.java': "Java",
        'macro.code.preset.html': "Insérer du code HTML brut",
        'macro.code.preset.xml': "XML",
        'macro.alert': "Alerte",
        'macro.alert.preset.success': "Succès",
        'macro.alert.preset.info': "Informations",
        'macro.alert.preset.warning': "Avertissement",
        'macro.alert.preset.danger': "Danger",
        'macro.flag': "Signalement",
        'macro.flag.preset.new': "Nouveau",
        'macro.flag.preset.updated': "Mis à jour",
        'macro.emoticon.presets': "Émoticônes",
        'macro.emoticon.preset.angry': "En colère",
        'macro.emoticon.preset.blush': "Embarrassé",
        'macro.emoticon.preset.confused': "Perplexe",
        'macro.emoticon.preset.cool': "Cool",
        'macro.emoticon.preset.cry': "Triste",
        'macro.emoticon.preset.devil': "Diable",
        'macro.emoticon.preset.grin': "Sourire",
        'macro.emoticon.preset.happy': "Heureux",
        'macro.emoticon.preset.laugh': "Rire",
        'macro.emoticon.preset.love': "Amour",
        'macro.emoticon.preset.mischief': "Espiègle",
        'macro.emoticon.preset.plain': "Normal",
        'macro.emoticon.preset.sad': "Triste",
        'macro.emoticon.preset.shocked': "Choqué",
        'macro.emoticon.preset.silly': "Loufoque",
        'macro.emoticon.preset.wink': "Clin d’oeil",
        'macro.emoticon.preset.info': "Informations",
        'macro.emoticon.preset.plus': "Plus",
        'macro.emoticon.preset.minus': "Moins",
        'macro.emoticon.preset.alert': "Alerte",
        'macro.emoticon.preset.check': "Vérifier",
        'macro.emoticon.preset.x': "Croix"
    });
});

;
require([
    'tinyMCE'
], function(tinyMCE) {
    tinyMCE.addI18n('fr.jivemacros',{
        add : 'Insérer',
        remove : 'Supprimer',
        properties : 'Paramètres',
        title : 'Paramètres',
        params : 'Paramètres',
        presets : 'Valeurs prédéfinies',
        save: "Enregistrer"
    });
});

;
require([
    'tinyMCE'
], function(tinyMCE) {
    tinyMCE.addI18n('fr.jiveattachment',{
        button_label : 'Joindre',
        removeAttachmentButton : 'Supprimer'
    });
});

;
require([
    'tinyMCE'
], function(tinyMCE) {
    tinyMCE.addI18n('fr.jiveapps',{
        edit_app : '! App'
    });
});

;
require([
    'tinyMCE'
], function(tinyMCE) {
    tinyMCE.addI18n('fr.jivemention',{
        mention_button_lbl : '@ Citation',
        no_notification : 'ne seront pas notifiés de cette citation, car ils n’ont pas accès à ce contenu.',
        secret_group_mention : 'est un groupe confidentiel. Toute personne pouvant accéder à ce contenu peut voir le nom du groupe confidentiel.',
        restricted_content_mention : 'se situe dans un groupe où le nombre de membres est limité. Toute personne pouvant accéder à ce contenu peut voir le nom de l’objet.',
        select_badge : 'Choisir un badge'
    });
});

;
require([
    'tinyMCE'
], function(tinyMCE) {
    tinyMCE.addI18n('fr.jivetable',{
        'transparent': "Transparent"
    });
});

;
require([
    'tinyMCE'
], function(tinyMCE) {
    tinyMCE.addI18n('fr.jivetablecontrols',{
        addRows : 'Ajouter {0} lignes {1}',
        ok : 'OK',
        add : 'Ajouter',
        rows : 'ligne(s)',
        add_row_before : 'Ajouter une ligne au-dessus',
        add_row_after : 'Ajouter une ligne en-dessous',
        delete_row : 'Supprimer la ligne',
        duplicate_row : 'Dupliquer la ligne',
        add_col_before : 'Ajouter une colonne à gauche',
        add_col_after : 'Ajouter une colonne à droite',
        delete_col : 'Supprimer la colonne',
        duplicate_col : 'Dupliquer la colonne'
    });
});

;
require([
    'tinyMCE'
], function(tinyMCE) {
    tinyMCE.addI18n('fr.jivetablebutton',{
        'header': "En-tête"
    });
});

;
require([
    'tinyMCE'
], function(tinyMCE) {
    tinyMCE.addI18n('fr.jiveemoticons',{
        title : 'Insérer une émoticône',
        desc : 'Émoticônes'
    });
});

;
require([
    'tinyMCE'
], function(tinyMCE) {
    tinyMCE.addI18n('fr.jivelink',{
        link_desc : 'Insérer un lien',
        unlink : 'Annuler le lien',
        bareUrl : 'Adresse URL nue',
        autoResolve : 'Titre automatique',
        menu_hdr : 'Lien :'
    });
});

;
require([
    'tinyMCE'
], function(tinyMCE) {
    tinyMCE.addI18n('fr.jiveimage',{
        link_desc : 'Insérer l\'\'image',
        menu_hdr : 'Image :',
        float_right : 'Flottant à droite',
        float_left : 'Flottant à gauche',
        inline : 'Afficher en interligne',
        original_size : 'Taille d’origine',
        please_wait : 'Veuillez patienter pendant le chargement des images, puis réessayez.'
    });
});

;
require([
    'tinyMCE'
], function(tinyMCE) {
    tinyMCE.addI18n('fr.jivequote',{
        link_desc : 'Citer le message précédent'
    });
});

;
require([
    'tinyMCE'
], function(tinyMCE) {
    tinyMCE.addI18n('fr.jivevideo',{
        link_desc : 'Insérer une vidéo'
    });
});


;
require([
    'tinyMCE'
], function(tinyMCE) {
    tinyMCE.addI18n('fr.jivevideo',{
        num1: "1. ",
        num2: "2. ",
        title_new:"Insérer une vidéo",
        general_props:"Propriétés vidéo",
        site_title:"Sélectionner un site de vidéos",
        embed_title: "Saisir les informations sur la vidéo",
        embed: "URL de la vidéo ou code incorporé (exemple : http://youtube.com/watch?v=videoIdHere)",
        embed_error : "Veuillez saisir un code URL valide ou intégrer le code",
        name_youtube: "YouTube",
        name_vimeo: "Vimeo",
        name_veoh: "Veoh",
        name_dailymotion: "Dailymotion",
        name_google: "Google",
        name_kaltura: "Kaltura",
        name_brightcove: "Brightcove",
        name_showandshare: "Afficher et partager"
    });
});

;
require([
    'tinyMCE'
], function(tinyMCE) {
    tinyMCE.addI18n('fr.tabletoolbar',{
        title : 'Insérer un tableau'
    });
});

;
require([
    'tinyMCE'
], function(tinyMCE) {
    tinyMCE.addI18n('fr.table_dlg',{
        general_tab:"G\u00E9n\u00E9ral",
        advanced_tab:"Avanc\u00E9",
        general_props:"Propri\u00E9t\u00E9s g\u00E9n\u00E9rales",
        advanced_props:"Propri\u00E9t\u00E9s avanc\u00E9es",
        rowtype:"Type de ligne",
        title:"Ins\u00E9rer/Modifier tableau",
        width:"Largeur",
        height:"Hauteur",
        cols:"Colonnes",
        rows:"Lignes",
        cellspacing:"Espacement des cellules",
        cellpadding:"Espacement dans les cellules",
        border:"Bordure",
        align:"Alignement",
        align_default:"Par defaut",
        align_left:"Gauche",
        align_right:"Droit",
        align_middle:"Centr\u00E9",
        row_title:"Propri\u00E9t\u00E9s de la ligne",
        cell_title:"Propri\u00E9t\u00E9s de la cellule",
        cell_type:"Type de cellule",
        valign:"Alignement vertical",
        align_top:"Haut",
        align_bottom:"Bas",
        bordercolor:"Couleur de la bordure",
        bgcolor:"Couleur du fond",
        merge_cells_title:"Fusioner les cellules",
        id:"Id",
        style:"Style",
        langdir:"Sens de lecture",
        langcode:"Code de la langue",
        mime:"Type MIME de la cible",
        ltr:"De gauche \u00E0 droite",
        rtl:"de droite \u00E0 gauche",
        bgimage:"Image de fond",
        summary:"R\u00E9sum\u00E9",
        td:"Donn\u00E9es",
        th:"Titre",
        cell_cell:"Mettre \u00E0 jour la cellule courante",
        cell_row:"Mettre \u00E0 jour toutes les cellules de la ligne",
        cell_all:"Mettre \u00E0 jour toutes les celluls du tableau",
        row_row:"Mettre \u00E0 jour la ligne courante",
        row_odd:"Mettre \u00E0 jour les lignes impaires",
        row_even:"Mettre \u00E0 jour les lignes paires",
        row_all:"Mettre \u00E0 jout toutes les lignes du tableau",
        thead:"T\u00EAte de tableau",
        tbody:"Corps de tableau",
        tfoot:"Pied de tableau",
        scope:"Port\u00E9e",
        rowgroup:"Groupe de lignes",
        colgroup:"Groupe de colonnes",
        col_limit:"Vous avez d\u00E9pass\u00E9 le nombre maximum de colonnes ({$cols}).",
        row_limit:"Vous avez d\u00E9pass\u00E9 le nombre maximum de lignes ({$rows}).",
        cell_limit:"Vous avez d\u00E9pass\u00E9 le nombre maximum de cellules ({$cells}).",
        missing_scope:"\u00CAtes-vous s\u00FBr de vouloir continuer sans sp\u00E9ficier de port\u00E9e pour cette cellule de titre\u00A0? Sans port\u00E9e, cela peut \u00EAtre difficile pour certains usagers \u00E0 probl\u00E8mes de comprendre le contenu ou les donn\u00E9es affich\u00E9es dans le tableau.",
        caption:"Afficher la l\u00E9gende du tableau",
        frame:"Cadre",
        frame_none:"aucun",
        frame_groups:"groupe",
        frame_rows:"lignes",
        frame_cols:"colonnes",
        frame_all:"tous",
        rules:"R\u00E8gles",
        rules_void:"nul",
        rules_above:"au dessus",
        rules_below:"au dessous",
        rules_hsides:"hsides",
        rules_lhs:"lhs",
        rules_rhs:"rhs",
        rules_vsides:"vsides",
        rules_box:"box",
        rules_border:"border"
    });
});

;
require([
    'tinyMCE'
], function(tinyMCE) {
    tinyMCE.addI18n('fr.table_dlg',{
        title_new:"Insérer un tableau",
        title_edit:"Modifier le tableau",
        merge_cells_description: "Choisissez le nombre de cellules à droite et en dessous de la cellule actuelle que vous souhaitez fusionner. Choisissez « 0 » si vous ne souhaitez fusionner aucune  cellule dans la direction donnée."
    });
});

;
require([
    'tinyMCE'
], function(tinyMCE) {
    tinyMCE.addI18n('fr.html',{
        desc:"Basculer en mode HTML"
    });
});

;
require([
    'tinyMCE'
], function(tinyMCE) {
    tinyMCE.addI18n('fr.advimage_dlg',{
        tab_general:"G\u00E9n\u00E9ral",
        tab_appearance:"Apparence",
        tab_advanced:"Avanc\u00E9",
        general:"G\u00E9n\u00E9ral",
        title:"Titre",
        preview:"Pr\u00E9visualiser",
        constrain_proportions:"Conserver les proportions",
        langdir:"Sens de lecture",
        langcode:"Code de la langue",
        long_desc:"Description longue du lien",
        style:"Style",
        classes:"Classes",
        ltr:"De gauche \u00E0 droite",
        rtl:"De droite \u00E0 gauche",
        id:"Id",
        map:"Carte image",
        swap_image:"Alterner image",
        alt_image:"Image alternative",
        mouseover:"au passage de la souris",
        mouseout:"\u00E0 la sortie de la souris",
        misc:"Divers",
        example_img:"Apparence de l'image",
        missing_alt:"\u00CAtes-vous s\u00FBr de vouloir continuer sans inclure de description de l'image\u00A0? Sans description, l'image peut ne pas \u00EAtre accessible \u00E0 certains utilisateurs handicap\u00E9s visuellement, ceux utilisant un navigateur texte, ou ceux qui naviguent sans affichage des images.",
        dialog_title:"Ins\u00E9rer/\u00C9diter image",
        src:"URL de l'image",
        alt:"Description de l'image",
        list:"Liste d'images",
        border:"Bordure",
        dimensions:"Dimensions",
        vspace:"Espacement vertical",
        hspace:"Espacement horizontal",
        align:"Alignement",
        align_baseline:"Base",
        align_top:"Haut",
        align_middle:"Milieu",
        align_bottom:"Bas",
        align_texttop:"Haut du texte",
        align_textbottom:"Bas du texte",
        align_left:"Gauche",
        align_right:"Droite",
        image_list:"Liste d'images"
    });
});

;
require([
    'tinyMCE'
], function(tinyMCE) {
    tinyMCE.addI18n('fr.advimage_dlg',{
        dialog_title:"Insérer une image",
        src:"Adresse URL",
        align_inline:"Normal",
        align_nowrap:"Pas de retour à la ligne",
        insert_desc : "Utilisez le formulaire ci-dessous pour insérer une image distante à partir d’une page Web dans votre discussion, votre document, votre billet de blog ou votre commentaire de blog.",
        from_the_web: "À partir du Web",
        example: "exemple",
        insert: "Insérer l\'\'image"
    });
});

;
require([
    'tinyMCE'
], function(tinyMCE) {
    tinyMCE.addI18n('fr.advlink_dlg',{
        title:"Ins\u00E9rer/\u00C9diter lien",
        url:"URL du lien",
        target:"Cible",
        titlefield:"Titre",
        is_email:"L'url que vous avez entr\u00E9 semble \u00EAtre une adresse e-mail, voulez-vous ajouter le pr\u00E9fixe mailto:\u00A0?",
        is_external:"L'url que vous avez entr\u00E9 semble \u00EAtre une adresse web externe, voulez-vous ajouter le pr\u00E9fixe http://\u00A0?",
        list:"Liste de liens",
        general_tab:"G\u00E9n\u00E9ral",
        popup_tab:"Popup",
        events_tab:"\u00C9v\u00E9nements",
        advanced_tab:"Advanc\u00E9",
        general_props:"Propri\u00E9t\u00E9s g\u00E9n\u00E9rales",
        popup_props:"Propri\u00E9t\u00E9s du popup",
        event_props:"\u00C9v\u00E9nements",
        advanced_props:"Propri\u00E9t\u00E9s avanc\u00E9es",
        popup_opts:"Options",
        anchor_names:"Ancres",
        target_same:"Ouvrir dans cette fen\u00EAtre / dans ce cadre",
        target_parent:"Ouvrir dans la fen\u00EAtre / le cadre parent",
        target_top:"Ouvrir dans le cadre principal (Remplace tous les cadres)",
        target_blank:"Ouvrir dans une nouvelle fen\u00EAtre",
        popup:"Popup en Javascript",
        popup_url:"URL du popup",
        popup_name:"Nom de la fen\u00EAtre",
        popup_return:"Ins\u00E9rer 'return false'",
        popup_scrollbars:"Afficher les ascenseurs",
        popup_statusbar:"Afficher la barre de status",
        popup_toolbar:"Afficher la barre d'outils",
        popup_menubar:"Afficher la barre de menu",
        popup_location:"Afficher la barre d'adresse",
        popup_resizable:"Rendre la fen\u00EAtre redimensionable",
        popup_dependent:"D\u00E9pendent (Seulement sous Mozilla/Firefox)",
        popup_size:"Taille",
        popup_position:"Position (X/Y)",
        id:"Id",
        style:"Style",
        classes:"Classes",
        target_name:"Nom de la cible",
        langdir:"Sens de lecture",
        target_langcode:"Langue de la cible",
        langcode:"Code de la langue",
        encoding:"Encodage de la cible",
        mime:"Type MIME de la cible",
        rel:"Relation de la page \u00E0 la cible",
        rev:"Relation de la cible \u00E0 la page",
        tabindex:"Tabindex",
        accesskey:"Touche d'acc\u00E8s rapide",
        ltr:"Gauche \u00E0 droite",
        rtl:"Droite \u00E0 gauche",
        link_list:"Liste des liens"
    });
});

;
require([
    'tinyMCE'
], function(tinyMCE) {
    tinyMCE.addI18n('fr.advanced',{
        style_select:"Styles",
        font_size:"Taille police",
        fontdefault:"Famille de police",
        block:"Format",
        paragraph:"Paragraphe",
        div:"Div",
        address:"Adresse",
        pre:"Preformatt\u00E9",
        h1:"Titre 1",
        h2:"Titre 2",
        h3:"Titre 3",
        h4:"Titre 4",
        h5:"Titre 5",
        h6:"Titre 6",
        blockquote:"Citation",
        code:"Code",
        samp:"Exemple de code",
        dt:"Terme \u00E0 d\u00E9finir",
        dd:"D\u00E9finition du terme",
        bold_desc:"Gras (Ctrl+B)",
        italic_desc:"Italique (Ctrl+I)",
        underline_desc:"Soulign\u00E9 (Ctrl+U)",
        striketrough_desc:"Barr\u00E9",
        justifyleft_desc:"Align\u00E9 \u00E0 gauche",
        justifycenter_desc:"Centr\u00E9",
        justifyright_desc:"Align\u00E9 \u00E0 droite",
        justifyfull_desc:"Justifi\u00E9",
        bullist_desc:"Liste non-num\u00E9rot\u00E9e",
        numlist_desc:"Liste num\u00E9rot\u00E9e",
        outdent_desc:"Retirer l'indentation",
        indent_desc:"Indenter",
        undo_desc:"Annuler (Ctrl+Z)",
        redo_desc:"R\u00E9tablir (Ctrl+Y)",
        link_desc:"Ins\u00E9rer/\u00C9diter le lien",
        unlink_desc:"D\u00E9lier",
        image_desc:"Ins\u00E9rer/\u00C9diter l'image",
        cleanup_desc:"Nettoyer le code non propre",
        code_desc:"\u00C9diter source HTML",
        sub_desc:"Indice",
        sup_desc:"Exposant",
        hr_desc:"Ins\u00E9rer trait horizontal",
        removeformat_desc:"Enlever formattage",
        custom1_desc:"Votre description personnalis\u00E9e ici",
        forecolor_desc:"Choisir la couleur du texte",
        backcolor_desc:"Choisir la couleur de surlignage",
        charmap_desc:"Ins\u00E9rer caract\u00E8res sp\u00E9ciaux",
        visualaid_desc:"Activer/d\u00E9sactiver les guides et les \u00E9l\u00E9ments invisibles",
        anchor_desc:"Ins\u00E9rer/\u00C9diter ancre",
        cut_desc:"Couper",
        copy_desc:"Copier",
        paste_desc:"Coller",
        image_props_desc:"Propri\u00E9t\u00E9s de l'image",
        newdocument_desc:"Nouveau document",
        help_desc:"Aide",
        blockquote_desc:"Citation",
        clipboard_msg:"Copier/Couper/Coller n'est pas disponible sous Mozilla et sous Firefox.\n\r\n      Voulez-vous plus d'information sur ce probl\u00E8me\u00A0?",
        path:"Chemin",
        newdocument:"\u00CAtes-vous s\u00FBr de vouloir effacer l'enti\u00E8ret\u00E9 du document\u00A0?",
        toolbar_focus:"Aller aux boutons de l'\u00E9diteur - Ctrl+Shift+Q, Aller \u00E0 l'\u00E9diteur - Alt-Z, Aller au chemin de l'\u00E9l\u00E9ment - Alt-X",
        more_colors:"Plus de couleurs"
    });
});

;
require([
    'tinyMCE'
], function(tinyMCE) {
    tinyMCE.addI18n('fr.advanced',{
        style_select: "Styles",
        font_size: "Taille de police",
        fontdefault: "Police",
        block: "Mise en forme",
        paragraph: "Paragraphe",
        div: "Div",
        address: "Adresse",
        pre: "Préformaté",
        h1: "En-tête 1",
        h2: "En-tête 2",
        h3: "En-tête 3",
        h4: "En-tête 4",
        h5: "En-tête 5",
        h6: "En-tête 6",
        blockquote: "Bloc de citation",
        code: "Code",
        samp: "Échantillon de code",
        dt: "Terme de définition",
        dd: "Description de la définition",
        bold_desc: "Gras (Ctrl+B)",
        italic_desc: "Italique (Ctrl+I)",
        underline_desc: "Souligner (Ctrl+U)",
        striketrough_desc: "Barré",
        justifyleft_desc: "Aligner à gauche",
        justifycenter_desc: "Aligner au centre",
        justifyright_desc: "Aligner à droite",
        justifyfull_desc: "Justifier",
        bullist_desc: "Liste non triée",
        numlist_desc: "Liste triée",
        outdent_desc: "Retrait négatif",
        indent_desc: "Retrait positif",
        undo_desc: "Annuler (Ctrl+Z)",
        redo_desc: "Rétablir (Ctrl+Y)",
        link_desc: "Insérer/modifier un lien",
        unlink_desc: "Annuler le lien",
        image_desc: "Insérer/modifier une image",
        cleanup_desc: "Nettoyer code compliqué",
        code_desc: "Modifier une source HTML",
        sub_desc: "Indice",
        sup_desc: "Exposant",
        hr_desc: "Insérer une règle horizontale",
        removeformat_desc: "Supprimer la mise en forme",
        custom1_desc: "Votre description personnalisée apparaît ici",
        forecolor_desc: "Sélectionner une couleur de texte",
        backcolor_desc: "Sélectionner la couleur de fond d’écran",
        charmap_desc: "Insérer un caractère personnalisé",
        visualaid_desc: "Basculer entre instructions et éléments invisibles",
        anchor_desc: "Insérer/modifier une ancre",
        cut_desc: "Couper",
        copy_desc: "Copier",
        paste_desc: "Coller",
        image_props_desc: "Propriétés de l’image",
        newdocument_desc: "Nouveau document",
        help_desc: "Aide",
        blockquote_desc: "Bloc de citation",
        clipboard_msg: "Les fonctions Couper/Copier/Coller ne sont pas disponibles dans Mozilla ni Firefox. Souhaitez-vous plus de renseignements à propos de ce problème ?",
        path: "Chemin",
        newdocument: "Êtes-vous sûr(e) de vouloir effacer tous les contenus ?",
        toolbar_focus: "Raccourci de boutons d’outils - Alt+Q",
        more_colors: "Autres couleurs",

        spellchecker_desc: "Vérifier l’orthographe",
        insert_image_desc: "Insérer l\'\'image",
        edit_image_desc: "Modifier l’image",

        colorpicker_apply:"Appliquer",
        colorpicker_color:"Couleur",
        colorpicker_picker_tab:"Nuancier",
        colorpicker_palette_tab:"Palette",
        colorpicker_named_tab:"Nommées",
        colorpicker_name:"Nom",
        colorpicker_picker_title:"Nuancier",
        colorpicker_palette_title:"Couleurs de la palette",
        colorpicker_named_title:"Couleurs nommées",
        colorpicker_title:"Nuancier"
    });
});

;
require([
    'tinyMCE'
], function(tinyMCE) {
    tinyMCE.addI18n('fr.advanced_dlg',{
        about_title:"\u00C0 propos de TinyMCE",
        about_general:"\u00C0 propos",
        about_help:"Aide",
        about_license:"Licence",
        about_plugins:"Plugins",
        about_plugin:"Plugin",
        about_author:"Auteur",
        about_version:"Version",
        about_loaded:"Plugins charg\u00E9s",
        anchor_title:"Ins\u00E9rer/\u00C9diter ancre",
        anchor_name:"Nom de l'ancre",
        code_title:"\u00C9diteur de la source HTML",
        code_wordwrap:"Rupture de ligne",
        colorpicker_title:"Choisir une couleur",
        colorpicker_picker_tab:"Nuancier",
        colorpicker_picker_title:"Nuancier",
        colorpicker_palette_tab:"Palette",
        colorpicker_palette_title:"Couleurs de la palette",
        colorpicker_named_tab:"Noms",
        colorpicker_named_title:"Couleurs nomm\u00E9es",
        colorpicker_color:"Couleur :",
        colorpicker_name:"Nom :",
        charmap_title:"Choisir le caract\u00E8re \u00E0 ins\u00E9rer",
        image_title:"Ins\u00E9rer/\u00C9diter image",
        image_src:"URL de l'image",
        image_alt:"Description de l'image",
        image_list:"Liste d'images",
        image_border:"Bordure",
        image_dimensions:"Dimensions",
        image_vspace:"Espacement vertical",
        image_hspace:"Espacement horizontal",
        image_align:"Alignement",
        image_align_baseline:"Base",
        image_align_top:"Sommet",
        image_align_middle:"Milieu",
        image_align_bottom:"Bas",
        image_align_texttop:"Haut du texte",
        image_align_textbottom:"Bas du texte",
        image_align_left:"Gauche",
        image_align_right:"Droite",
        link_title:"Ins\u00E9rer/\u00C9diter lien",
        link_url:"URL du lien",
        link_target:"Cible",
        link_target_same:"Ouvrir dans la m\u00EAme fen\u00EAtre",
        link_target_blank:"Ouvrir dans une nouvelle fen\u00EAtre",
        link_titlefield:"Titre",
        link_is_email:"L'url que vous avez entr\u00E9 semble \u00EAtre une adresse e-mail, voulez-vous ajouter le pr\u00E9fixe mailto:\u00A0?",
        link_is_external:"L'url que vous avez entr\u00E9 semble \u00EAtre une adresse web externe, voulez-vous ajouter le pr\u00E9fixe http://\u00A0?",
        link_list:"Liste de liens"
    });
});

;
