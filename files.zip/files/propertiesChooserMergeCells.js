// This file was automatically generated from propertiesChooserMergeCells.soy.
// Please don't edit this file by hand.

goog.provide('jive.rte.table.propertiesChooserMergeCells');

goog.require('soy');
goog.require('soydata');
goog.require('soy.StringBuilder');


jive.rte.table.propertiesChooserMergeCells = function(opt_data, opt_sb) {
  var output = opt_sb || new soy.StringBuilder();
  output.append(soy.$$escapeHtml(jive.i18n._i18n('b08cf0',[])));
  return opt_sb ? '' : output.toString();
};
