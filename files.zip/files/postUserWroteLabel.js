// This file was automatically generated from postUserWroteLabel.soy.
// Please don't edit this file by hand.

goog.provide('jive.i18n.keys.postUserWroteLabel');

goog.require('soy');
goog.require('soydata');
goog.require('soy.StringBuilder');


jive.i18n.keys.postUserWroteLabel = function(opt_data, opt_sb) {
  var output = opt_sb || new soy.StringBuilder();
  output.append(soy.$$escapeHtml(jive.i18n._i18n('5c3bce',[])));
  return opt_sb ? '' : output.toString();
};
