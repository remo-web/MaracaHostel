// This file was automatically generated from propertiesChooserColumn.soy.
// Please don't edit this file by hand.

goog.provide('jive.rte.table.propertiesChooserColumn');

goog.require('soy');
goog.require('soydata');
goog.require('soy.StringBuilder');


jive.rte.table.propertiesChooserColumn = function(opt_data, opt_sb) {
  var output = opt_sb || new soy.StringBuilder();
  output.append(soy.$$escapeHtml(jive.i18n._i18n('e99393',[])));
  return opt_sb ? '' : output.toString();
};
