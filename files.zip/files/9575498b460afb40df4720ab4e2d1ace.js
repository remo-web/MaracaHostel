var default_lang = {
"childNodes": [
	{
	"childNodes": [
		{
		"tagName": "lang_id",
		"childNodes": [{ "nodeValue": "1"
}]
		},
		{
		"tagName": "name",
		"childNodes": [{ "nodeValue": "French"
}]
		},
		{
		"childNodes": [
			{
			"tagName": "eng_name",
			"childNodes": [{ "nodeValue": "French"
}]
			},
			{
			"tagName": "name",
			"childNodes": [{ "nodeValue": "French"
}]
			},
			{
			"tagName": "january",
			"childNodes": [{ "nodeValue": "janvier"
}]
			},
			{
			"tagName": "february",
			"childNodes": [{ "nodeValue": "février"
}]
			},
			{
			"tagName": "march",
			"childNodes": [{ "nodeValue": "mars"
}]
			},
			{
			"tagName": "april",
			"childNodes": [{ "nodeValue": "Avril"
}]
			},
			{
			"tagName": "may",
			"childNodes": [{ "nodeValue": "Mai"
}]
			},
			{
			"tagName": "june",
			"childNodes": [{ "nodeValue": "Juin"
}]
			},
			{
			"tagName": "july",
			"childNodes": [{ "nodeValue": "juillet"
}]
			},
			{
			"tagName": "august",
			"childNodes": [{ "nodeValue": "août"
}]
			},
			{
			"tagName": "september",
			"childNodes": [{ "nodeValue": "septembre"
}]
			},
			{
			"tagName": "october",
			"childNodes": [{ "nodeValue": "octobre"
}]
			},
			{
			"tagName": "november",
			"childNodes": [{ "nodeValue": "novembre"
}]
			},
			{
			"tagName": "december",
			"childNodes": [{ "nodeValue": "décembre"
}]
			},
			{
			"tagName": "sunday",
			"childNodes": [{ "nodeValue": "dimanche"
}]
			},
			{
			"tagName": "monday",
			"childNodes": [{ "nodeValue": "lundi"
}]
			},
			{
			"tagName": "tuesday",
			"childNodes": [{ "nodeValue": "mardi"
}]
			},
			{
			"tagName": "wednesday",
			"childNodes": [{ "nodeValue": "mercredi"
}]
			},
			{
			"tagName": "thursday",
			"childNodes": [{ "nodeValue": "jeudi"
}]
			},
			{
			"tagName": "friday",
			"childNodes": [{ "nodeValue": "vendredi"
}]
			},
			{
			"tagName": "saturday",
			"childNodes": [{ "nodeValue": "samedi"
}]
			},
			{
			"tagName": "sh_january",
			"childNodes": [{ "nodeValue": "jan"
}]
			},
			{
			"tagName": "sh_february",
			"childNodes": [{ "nodeValue": "fév"
}]
			},
			{
			"tagName": "sh_march",
			"childNodes": [{ "nodeValue": "mar"
}]
			},
			{
			"tagName": "sh_april",
			"childNodes": [{ "nodeValue": "avr"
}]
			},
			{
			"tagName": "sh_may",
			"childNodes": [{ "nodeValue": "Mai"
}]
			},
			{
			"tagName": "sh_june",
			"childNodes": [{ "nodeValue": "juin"
}]
			},
			{
			"tagName": "sh_july",
			"childNodes": [{ "nodeValue": "juil"
}]
			},
			{
			"tagName": "sh_august",
			"childNodes": [{ "nodeValue": "aoû"
}]
			},
			{
			"tagName": "sh_september",
			"childNodes": [{ "nodeValue": "sept"
}]
			},
			{
			"tagName": "sh_october",
			"childNodes": [{ "nodeValue": "oct"
}]
			},
			{
			"tagName": "sh_november",
			"childNodes": [{ "nodeValue": "nov"
}]
			},
			{
			"tagName": "sh_december",
			"childNodes": [{ "nodeValue": "déc"
}]
			},
			{
			"tagName": "sh_sunday",
			"childNodes": [{ "nodeValue": "dim"
}]
			},
			{
			"tagName": "sh_monday",
			"childNodes": [{ "nodeValue": "lun"
}]
			},
			{
			"tagName": "sh_tuesday",
			"childNodes": [{ "nodeValue": "mar"
}]
			},
			{
			"tagName": "sh_wednesday",
			"childNodes": [{ "nodeValue": "mer"
}]
			},
			{
			"tagName": "sh_thursday",
			"childNodes": [{ "nodeValue": "jeu"
}]
			},
			{
			"tagName": "sh_friday",
			"childNodes": [{ "nodeValue": "ven"
}]
			},
			{
			"tagName": "sh_saturday",
			"childNodes": [{ "nodeValue": "sam"
}]
			},
			{
			"tagName": "loading",
			"childNodes": [{ "nodeValue": "Chargement en cours…"
}]
			},
			{
			"tagName": "sb_actions",
			"childNodes": [{ "nodeValue": "Actions"
}]
			},
			{
			"tagName": "sb_my_calendars",
			"childNodes": [{ "nodeValue": "Mes calendriers"
}]
			},
			{
			"tagName": "sb_other_calendars",
			"childNodes": [{ "nodeValue": "Autres calendriers"
}]
			},
			{
			"tagName": "sb_alerts",
			"childNodes": [{ "nodeValue": "Alertes"
}]
			},
			{
			"tagName": "sb_general_tasks",
			"childNodes": [{ "nodeValue": "Tâches générales"
}]
			},
			{
			"tagName": "sb_no_tasks",
			"childNodes": [{ "nodeValue": "aucune tâche"
}]
			},
			{
			"tagName": "sb_reminder",
			"childNodes": [{ "nodeValue": "Rappel"
}]
			},
			{
			"tagName": "sb_reminders",
			"childNodes": [{ "nodeValue": "Rappels"
}]
			},
			{
			"tagName": "sb_alert",
			"childNodes": [{ "nodeValue": "Alerte"
}]
			},
			{
			"tagName": "motto",
			"childNodes": [{ "nodeValue": "Une gestion du temps tout à fait exceptionnelle"
}]
			},
			{
			"tagName": "nav_month",
			"childNodes": [{ "nodeValue": "mois"
}]
			},
			{
			"tagName": "nav_week",
			"childNodes": [{ "nodeValue": "semaine"
}]
			},
			{
			"tagName": "nav_day",
			"childNodes": [{ "nodeValue": "jour"
}]
			},
			{
			"tagName": "nav_today",
			"childNodes": [{ "nodeValue": "aujourd’hui"
}]
			},
			{
			"tagName": "nav_tomorrow",
			"childNodes": [{ "nodeValue": "demain"
}]
			},
			{
			"tagName": "nav_refresh",
			"childNodes": [{ "nodeValue": "actualiser"
}]
			},
			{
			"tagName": "nav_list",
			"childNodes": [{ "nodeValue": "liste"
}]
			},
			{
			"tagName": "nav_overview",
			"childNodes": [{ "nodeValue": "présentation"
}]
			},
			{
			"tagName": "nav_feedback",
			"childNodes": [{ "nodeValue": "avis"
}]
			},
			{
			"tagName": "nav_send",
			"childNodes": [{ "nodeValue": "Envoyer"
}]
			},
			{
			"tagName": "nav_settings",
			"childNodes": [{ "nodeValue": "paramètres"
}]
			},
			{
			"tagName": "nav_advanced",
			"childNodes": [{ "nodeValue": "avancé"
}]
			},
			{
			"tagName": "nav_logout",
			"childNodes": [{ "nodeValue": "déconnexion"
}]
			},
			{
			"tagName": "nav_prelogout",
			"childNodes": [{ "nodeValue": "Les modifications non enregistrées seront perdues !"
}]
			},
			{
			"tagName": "nav_back",
			"childNodes": [{ "nodeValue": "Retour à :"
}]
			},
			{
			"tagName": "nav_event",
			"childNodes": [{ "nodeValue": "événement"
}]
			},
			{
			"tagName": "nav_task",
			"childNodes": [{ "nodeValue": "tâche"
}]
			},
			{
			"tagName": "nav_invite",
			"childNodes": [{ "nodeValue": "Inviter !"
}]
			},
			{
			"tagName": "nav_save",
			"childNodes": [{ "nodeValue": "Enregistrer"
}]
			},
			{
			"tagName": "nav_filter",
			"childNodes": [{ "nodeValue": "filtrer"
}]
			},
			{
			"tagName": "feedback_title",
			"childNodes": [{ "nodeValue": "Que pensez-vous de Jotlet ?"
}]
			},
			{
			"tagName": "feedback_name",
			"childNodes": [{ "nodeValue": "votre nom :"
}]
			},
			{
			"tagName": "feedback_body",
			"childNodes": [{ "nodeValue": "nous apprécions la franchise :"
}]
			},
			{
			"tagName": "feedback_error",
			"childNodes": [{ "nodeValue": "Une erreur s’est produite lors de l’envoi de votre avis. Veuillez réessayer dans quelques minutes."
}]
			},
			{
			"tagName": "feedback_thanks",
			"childNodes": [{ "nodeValue": "Nous vous remercions de nous avoir fait part de votre avis !"
}]
			},
			{
			"tagName": "cal_create",
			"childNodes": [{ "nodeValue": "créer un calendrier"
}]
			},
			{
			"tagName": "cal_add",
			"childNodes": [{ "nodeValue": "Ajouter un calendrier"
}]
			},
			{
			"tagName": "cal_edit",
			"childNodes": [{ "nodeValue": "Modifier calendrier"
}]
			},
			{
			"tagName": "cal_delete",
			"childNodes": [{ "nodeValue": "Effacer un calendrier"
}]
			},
			{
			"tagName": "cal_remove",
			"childNodes": [{ "nodeValue": "Supprimer le calendrier"
}]
			},
			{
			"tagName": "cal_name",
			"childNodes": [{ "nodeValue": "nom du calendrier"
}]
			},
			{
			"tagName": "cal_color",
			"childNodes": [{ "nodeValue": "sélectionnez une couleur à appliquer au calendrier :"
}]
			},
			{
			"tagName": "color_red",
			"childNodes": [{ "nodeValue": "rouge"
}]
			},
			{
			"tagName": "color_blue",
			"childNodes": [{ "nodeValue": "bleu"
}]
			},
			{
			"tagName": "color_green",
			"childNodes": [{ "nodeValue": "vert"
}]
			},
			{
			"tagName": "color_pink",
			"childNodes": [{ "nodeValue": "rose"
}]
			},
			{
			"tagName": "color_purple",
			"childNodes": [{ "nodeValue": "violet"
}]
			},
			{
			"tagName": "color_orange",
			"childNodes": [{ "nodeValue": "orange"
}]
			},
			{
			"tagName": "color_yellow",
			"childNodes": [{ "nodeValue": "jaune"
}]
			},
			{
			"tagName": "color_grey",
			"childNodes": [{ "nodeValue": "gris"
}]
			},
			{
			"tagName": "nav_close",
			"childNodes": [{ "nodeValue": "Fermer"
}]
			},
			{
			"tagName": "nav_cancel",
			"childNodes": [{ "nodeValue": "Annuler"
}]
			},
			{
			"tagName": "event_menu",
			"childNodes": [{ "nodeValue": "Ajouter l’événement à…"
}]
			},
			{
			"tagName": "event_edit",
			"childNodes": [{ "nodeValue": "modifier l’événement"
}]
			},
			{
			"tagName": "event_edit_cap",
			"childNodes": [{ "nodeValue": "Modifier l’événement"
}]
			},
			{
			"tagName": "event_loading",
			"childNodes": [{ "nodeValue": "Chargement de la page Ajout d’événement en cours…"
}]
			},
			{
			"tagName": "event_add",
			"childNodes": [{ "nodeValue": "ajouter un événement"
}]
			},
			{
			"tagName": "event_title",
			"childNodes": [{ "nodeValue": "titre de l’événement"
}]
			},
			{
			"tagName": "event_dt",
			"childNodes": [{ "nodeValue": "date &amp; heure"
}]
			},
			{
			"tagName": "event_begins",
			"childNodes": [{ "nodeValue": "commence"
}]
			},
			{
			"tagName": "event_ends",
			"childNodes": [{ "nodeValue": "se termine"
}]
			},
			{
			"tagName": "event_at",
			"childNodes": [{ "nodeValue": "à"
}]
			},
			{
			"tagName": "event_allday",
			"childNodes": [{ "nodeValue": "Cet événement se déroule sur toute une journée"
}]
			},
			{
			"tagName": "event_repeats",
			"childNodes": [{ "nodeValue": "Cet événement a lieu plusieurs fois"
}]
			},
			{
			"tagName": "event_desc",
			"childNodes": [{ "nodeValue": "description"
}]
			},
			{
			"tagName": "event_add_cap",
			"childNodes": [{ "nodeValue": "Ajouter un événement"
}]
			},
			{
			"tagName": "event_update",
			"childNodes": [{ "nodeValue": "Mettre à jour un événement"
}]
			},
			{
			"tagName": "event_remind",
			"childNodes": [{ "nodeValue": "Ajouter un rappel"
}]
			},
			{
			"tagName": "event_sb_delete",
			"childNodes": [{ "nodeValue": "Supprimer cet événement"
}]
			},
			{
			"tagName": "event_sb_delete_series",
			"childNodes": [{ "nodeValue": "Supprimer cette série"
}]
			},
			{
			"tagName": "event_sb_edit",
			"childNodes": [{ "nodeValue": "Modifier cet événement"
}]
			},
			{
			"tagName": "event_sb_export",
			"childNodes": [{ "nodeValue": "Télécharger cet événement"
}]
			},
			{
			"tagName": "event_sb_perm",
			"childNodes": [{ "nodeValue": "Il s’agit d’un calendrier partagé. Vous n’êtes pas autorisé(e) à modifier ou à en supprimer des informations."
}]
			},
			{
			"tagName": "task_menu",
			"childNodes": [{ "nodeValue": "Ajouter une tâche à…"
}]
			},
			{
			"tagName": "task_edit",
			"childNodes": [{ "nodeValue": "modifier une tâche"
}]
			},
			{
			"tagName": "task_loading",
			"childNodes": [{ "nodeValue": "Chargement de la page d’ajout de tâche en cours…"
}]
			},
			{
			"tagName": "task_title",
			"childNodes": [{ "nodeValue": "titre de tâche"
}]
			},
			{
			"tagName": "task_due_date",
			"childNodes": [{ "nodeValue": "date d’échéance"
}]
			},
			{
			"tagName": "task_due",
			"childNodes": [{ "nodeValue": "date d’échéance"
}]
			},
			{
			"tagName": "task_no_due",
			"childNodes": [{ "nodeValue": "Aucune date butoir n’est associée à cette tâche"
}]
			},
			{
			"tagName": "task_repeats",
			"childNodes": [{ "nodeValue": "Cette tâche se répète"
}]
			},
			{
			"tagName": "task_add_cap",
			"childNodes": [{ "nodeValue": "Ajouter une tâche"
}]
			},
			{
			"tagName": "task_update",
			"childNodes": [{ "nodeValue": "Mettre à jour une tâche"
}]
			},
			{
			"tagName": "task_add",
			"childNodes": [{ "nodeValue": "ajouter une tâche"
}]
			},
			{
			"tagName": "task_sb_delete",
			"childNodes": [{ "nodeValue": "Supprimer cette tâche"
}]
			},
			{
			"tagName": "task_sb_delete_series",
			"childNodes": [{ "nodeValue": "Supprimer cette série"
}]
			},
			{
			"tagName": "task_sb_edit",
			"childNodes": [{ "nodeValue": "Modifier cette tâche"
}]
			},
			{
			"tagName": "task_sb_export",
			"childNodes": [{ "nodeValue": "Télécharger cette tâche"
}]
			},
			{
			"tagName": "task_sb_perm",
			"childNodes": [{ "nodeValue": "Il s’agit d’un calendrier partagé. Vous n’êtes pas autorisé(e) à modifier ou à supprimer des informations."
}]
			},
			{
			"tagName": "info_in_cal",
			"childNodes": [{ "nodeValue": "dans le calendrier %sub%"
}]
			},
			{
			"tagName": "info_no_desc",
			"childNodes": [{ "nodeValue": "aucune description"
}]
			},
			{
			"tagName": "info_on",
			"childNodes": [{ "nodeValue": "activé"
}]
			},
			{
			"tagName": "info_never",
			"childNodes": [{ "nodeValue": "Jamais"
}]
			},
			{
			"tagName": "info_no_title",
			"childNodes": [{ "nodeValue": "aucun titre"
}]
			},
			{
			"tagName": "info_more",
			"childNodes": [{ "nodeValue": "Plus d’infos"
}]
			},
			{
			"tagName": "info_allday",
			"childNodes": [{ "nodeValue": "Toute la journée"
}]
			},
			{
			"tagName": "info_minutes",
			"childNodes": [{ "nodeValue": "minutes"
}]
			},
			{
			"tagName": "info_hours",
			"childNodes": [{ "nodeValue": "heures"
}]
			},
			{
			"tagName": "info_duration",
			"childNodes": [{ "nodeValue": "durée"
}]
			},
			{
			"tagName": "day_notes",
			"childNodes": [{ "nodeValue": "cliquez ici pour ajouter des remarques quotidiennes"
}]
			},
			{
			"tagName": "day_tasks",
			"childNodes": [{ "nodeValue": "Tâches de la journée"
}]
			},
			{
			"tagName": "day_add_task",
			"childNodes": [{ "nodeValue": "ajouter une nouvelle tâche"
}]
			},
			{
			"tagName": "day_all_day",
			"childNodes": [{ "nodeValue": "Événements sur toute une journée"
}]
			},
			{
			"tagName": "day_click",
			"childNodes": [{ "nodeValue": "cliquez ici pour ajouter des remarques"
}]
			},
			{
			"tagName": "day_saving",
			"childNodes": [{ "nodeValue": "enregistrement en cours…"
}]
			},
			{
			"tagName": "day_loading",
			"childNodes": [{ "nodeValue": "chargement en cours…"
}]
			},
			{
			"tagName": "manage_cal",
			"childNodes": [{ "nodeValue": "Gestion du calendrier"
}]
			},
			{
			"tagName": "manage_prop",
			"childNodes": [{ "nodeValue": "propriétés des calendriers"
}]
			},
			{
			"tagName": "manage_share",
			"childNodes": [{ "nodeValue": "partager le calendrier"
}]
			},
			{
			"tagName": "manage_export",
			"childNodes": [{ "nodeValue": "exporter le calendrier"
}]
			},
			{
			"tagName": "manage_delete",
			"childNodes": [{ "nodeValue": "effacer un calendrier :"
}]
			},
			{
			"tagName": "manage_remove",
			"childNodes": [{ "nodeValue": "supprimer un calendrier :"
}]
			},
			{
			"tagName": "manage_edit",
			"childNodes": [{ "nodeValue": "modifier un calendrier"
}]
			},
			{
			"tagName": "manage_select_buddies",
			"childNodes": [{ "nodeValue": "Sélectionnez les camarades avec lesquels vous souhaitez partager à partir de la liste sur la droite"
}]
			},
			{
			"tagName": "manage_add_buddy",
			"childNodes": [{ "nodeValue": "Ajouter un camarade"
}]
			},
			{
			"tagName": "manage_add_buddy_link",
			"childNodes": [{ "nodeValue": "Ajouter un camarade !"
}]
			},
			{
			"tagName": "manage_no_buddies",
			"childNodes": [{ "nodeValue": "Il n’y a pas de copains ici :("
}]
			},
			{
			"tagName": "manage_buddy_email",
			"childNodes": [{ "nodeValue": "saisir l’adresse e-mail de votre camarade"
}]
			},
			{
			"tagName": "manage_buddy_name",
			"childNodes": [{ "nodeValue": "Nom du camarade :"
}]
			},
			{
			"tagName": "manage_invite_buddy",
			"childNodes": [{ "nodeValue": "Invitez votre camarade !"
}]
			},
			{
			"tagName": "manage_invite_buddy_to",
			"childNodes": [{ "nodeValue": "Inviter %sub% à Jotlet !"
}]
			},
			{
			"tagName": "manage_go_back",
			"childNodes": [{ "nodeValue": "Retourner"
}]
			},
			{
			"tagName": "manage_share_bang",
			"childNodes": [{ "nodeValue": "Partager !"
}]
			},
			{
			"tagName": "manage_share_self",
			"childNodes": [{ "nodeValue": "Vous ne pouvez pas partager avec vous-même ! :)"
}]
			},
			{
			"tagName": "manage_buddy_in_list",
			"childNodes": [{ "nodeValue": "%sub% figure déjà dans votre liste de camarades"
}]
			},
			{
			"tagName": "manage_valid_email",
			"childNodes": [{ "nodeValue": "Veuillez saisir une adresse e-mail valide"
}]
			},
			{
			"tagName": "manage_searching",
			"childNodes": [{ "nodeValue": "Recherche en cours…"
}]
			},
			{
			"tagName": "manage_adding_buddy",
			"childNodes": [{ "nodeValue": "Ajout d’un camarade en cours…"
}]
			},
			{
			"tagName": "manage_done_sharing",
			"childNodes": [{ "nodeValue": "Partage effectué !"
}]
			},
			{
			"tagName": "manage_error",
			"childNodes": [{ "nodeValue": "Une erreur s’est produite lors de la tentative de partage"
}]
			},
			{
			"tagName": "manage_sharing",
			"childNodes": [{ "nodeValue": "Partage avec un camarade en cours……"
}]
			},
			{
			"tagName": "manage_add_fail",
			"childNodes": [{ "nodeValue": "impossible d’ajouter un camarade :("
}]
			},
			{
			"tagName": "manage_inviting",
			"childNodes": [{ "nodeValue": "Invitation d’un camarade en cours…"
}]
			},
			{
			"tagName": "manage_done_inviting",
			"childNodes": [{ "nodeValue": "Invitation effectuée !"
}]
			},
			{
			"tagName": "manage_fail_inviting",
			"childNodes": [{ "nodeValue": "Erreur lors de l’invitation"
}]
			},
			{
			"tagName": "manage_done_invite_msg",
			"childNodes": [{ "nodeValue": "We’ll let you know when your buddy has accepted the invitation to Jotlet."
}]
			},
			{
			"tagName": "manage_fail_invite_msg",
			"childNodes": [{ "nodeValue": "Une erreur s’est produite lors de l’envoi de l’invitation à votre camarade. Veuillez réessayer dans quelques minutes."
}]
			},
			{
			"tagName": "manage_subscribe",
			"childNodes": [{ "nodeValue": "S’abonner"
}]
			},
			{
			"tagName": "manage_export_bang",
			"childNodes": [{ "nodeValue": "Exporter"
}]
			},
			{
			"tagName": "confirm_del_cal",
			"childNodes": [{ "nodeValue": "Supprimer le calendrier \"%sub%\" ?\nCette action ne pourra pas être annulée !"
}]
			},
			{
			"tagName": "confirm_rem_cal",
			"childNodes": [{ "nodeValue": "Supprimer le calendrier \"%sub%\" ?\nCette action ne peut être annulée !"
}]
			},
			{
			"tagName": "confirm_del_event",
			"childNodes": [{ "nodeValue": "Supprimer l’événement \"%sub%\" ?\nCette action ne pourra pas être annulée !"
}]
			},
			{
			"tagName": "confirm_del_event_s",
			"childNodes": [{ "nodeValue": "Supprimer la série d’événements contenant \"%sub%\" ?\nCette action ne peut être annulée !"
}]
			},
			{
			"tagName": "confirm_del_task",
			"childNodes": [{ "nodeValue": "Supprimer la tâche \"%sub%\" ?\nCeci ne pourra pas être annulé !"
}]
			},
			{
			"tagName": "confirm_del_task_s",
			"childNodes": [{ "nodeValue": "Supprimer la série de tâches contenant \"%sub%\" ?\nCette action ne peut être annulée !"
}]
			},
			{
			"tagName": "setting_title",
			"childNodes": [{ "nodeValue": "Paramètres personnels"
}]
			},
			{
			"tagName": "setting_first",
			"childNodes": [{ "nodeValue": "Prénom"
}]
			},
			{
			"tagName": "setting_last",
			"childNodes": [{ "nodeValue": "Nom de famille"
}]
			},
			{
			"tagName": "setting_email",
			"childNodes": [{ "nodeValue": "Adresse e-mail"
}]
			},
			{
			"tagName": "setting_sms",
			"childNodes": [{ "nodeValue": "SMS"
}]
			},
			{
			"tagName": "setting_zip",
			"childNodes": [{ "nodeValue": "Code postal"
}]
			},
			{
			"tagName": "setting_language",
			"childNodes": [{ "nodeValue": "Langue"
}]
			},
			{
			"tagName": "setting_save",
			"childNodes": [{ "nodeValue": "Enregistrer le profil"
}]
			},
			{
			"tagName": "setting_old_pass",
			"childNodes": [{ "nodeValue": "Ancien mot de passe"
}]
			},
			{
			"tagName": "setting_new_pass",
			"childNodes": [{ "nodeValue": "Nouveau mot de passe"
}]
			},
			{
			"tagName": "setting_confirm",
			"childNodes": [{ "nodeValue": "Confirmer"
}]
			},
			{
			"tagName": "setting_save_pass",
			"childNodes": [{ "nodeValue": "Mettre à jour le mot de passe"
}]
			},
			{
			"tagName": "setting_zone",
			"childNodes": [{ "nodeValue": "Fuseau horaire"
}]
			},
			{
			"tagName": "setting_zone_desc",
			"childNodes": [{ "nodeValue": "Les fuseaux horaires répertoriés sont associés à un * s’ils appliquent l’heure d’été"
}]
			},
			{
			"tagName": "setting_save_zone",
			"childNodes": [{ "nodeValue": "Enregistrer les paramètres locaux"
}]
			},
			{
			"tagName": "setting_zoom",
			"childNodes": [{ "nodeValue": "Niveau de zoom"
}]
			},
			{
			"tagName": "setting_zoom_desc",
			"childNodes": [{ "nodeValue": "Le niveau de zoom a une incidence sur la durée représentée par chaque ligne dans l’affichage du jour. Le zoom d’1 heure s’affichera en mode compact, tandis que le zoom de 15 minutes affichera plus de détails."
}]
			},
			{
			"tagName": "setting_zoom_15_min",
			"childNodes": [{ "nodeValue": "15 minutes"
}]
			},
			{
			"tagName": "setting_zoom_30_min",
			"childNodes": [{ "nodeValue": "30 minutes"
}]
			},
			{
			"tagName": "setting_zoom_1_hour",
			"childNodes": [{ "nodeValue": "1 heure"
}]
			},
			{
			"tagName": "setting_save_zoom",
			"childNodes": [{ "nodeValue": "Enregistrer le zoom"
}]
			},
			{
			"tagName": "setting_shade",
			"childNodes": [{ "nodeValue": "Cellules avec ombrage intelligent"
}]
			},
			{
			"tagName": "setting_shade_desc",
			"childNodes": [{ "nodeValue": "La fonction d’ombrage intelligent fonce automatiquement l’arrière-plan des jours les plus chargés dans l’affichage du mois. Plus le jour est chargé, plus la cellule est sombre."
}]
			},
			{
			"tagName": "setting_save_shade",
			"childNodes": [{ "nodeValue": "Enregistrer les paramètres de mois"
}]
			},
			{
			"tagName": "setting_profile",
			"childNodes": [{ "nodeValue": "profil d’utilisateur"
}]
			},
			{
			"tagName": "setting_change_pass",
			"childNodes": [{ "nodeValue": "modifier le mot de passe"
}]
			},
			{
			"tagName": "setting_time_zones",
			"childNodes": [{ "nodeValue": "fuseaux horaires"
}]
			},
			{
			"tagName": "setting_day_view",
			"childNodes": [{ "nodeValue": "affichage du jour"
}]
			},
			{
			"tagName": "setting_month_view",
			"childNodes": [{ "nodeValue": "affichage du mois"
}]
			},
			{
			"tagName": "setting_start_week",
			"childNodes": [{ "nodeValue": "Début de la semaine :"
}]
			},
			{
			"tagName": "err_cal_name",
			"childNodes": [{ "nodeValue": "Veuillez saisir le nom du calendrier"
}]
			},
			{
			"tagName": "email_invite",
			"childNodes": [{ "nodeValue": "Hey!\n\nCheck out Jotlet Calendar at www.jotlet.net! It’s a great looking and easy to use online calendar.\n\nSign up so I can share my schedule with you!"
}]
			},
			{
			"tagName": "err_task_title",
			"childNodes": [{ "nodeValue": "Veuillez saisir un titre pour votre tâche."
}]
			},
			{
			"tagName": "err_event_title",
			"childNodes": [{ "nodeValue": "Veuillez saisir un titre pour votre événement."
}]
			},
			{
			"tagName": "remind_adding",
			"childNodes": [{ "nodeValue": "Ajout de rappel en cours…"
}]
			},
			{
			"tagName": "remind_loading",
			"childNodes": [{ "nodeValue": "Chargement du rappel en cours…"
}]
			},
			{
			"tagName": "remind_email",
			"childNodes": [{ "nodeValue": "Adresse e-mail"
}]
			},
			{
			"tagName": "remind_sms",
			"childNodes": [{ "nodeValue": "Message texte"
}]
			},
			{
			"tagName": "remind_both",
			"childNodes": [{ "nodeValue": "Les deux"
}]
			},
			{
			"tagName": "remind_5_min",
			"childNodes": [{ "nodeValue": "5 minutes"
}]
			},
			{
			"tagName": "remind_4_hour",
			"childNodes": [{ "nodeValue": "4 heures"
}]
			},
			{
			"tagName": "remind_0_day",
			"childNodes": [{ "nodeValue": "le même jour"
}]
			},
			{
			"tagName": "remind_1_day",
			"childNodes": [{ "nodeValue": "la veille"
}]
			},
			{
			"tagName": "remind_2_day",
			"childNodes": [{ "nodeValue": "2 jours avant"
}]
			},
			{
			"tagName": "remind_3_day",
			"childNodes": [{ "nodeValue": "3 jours avant"
}]
			},
			{
			"tagName": "remind_4_day",
			"childNodes": [{ "nodeValue": "4 jours avant"
}]
			},
			{
			"tagName": "remind_5_day",
			"childNodes": [{ "nodeValue": "5 jours avant"
}]
			},
			{
			"tagName": "remind_1_week",
			"childNodes": [{ "nodeValue": "1 semaine avant"
}]
			},
			{
			"tagName": "remind_2_week",
			"childNodes": [{ "nodeValue": "2 semaines avant"
}]
			},
			{
			"tagName": "remind_event",
			"childNodes": [{ "nodeValue": "Envoyez-moi un %email% %time% avant cet événement"
}]
			},
			{
			"tagName": "remind_task_due",
			"childNodes": [{ "nodeValue": "Envoyez-moi un %email% à %time%%date% de sa date d’échéance"
}]
			},
			{
			"tagName": "remind_task_no",
			"childNodes": [{ "nodeValue": "Envoyez-moi un %email% à %time% le %date%"
}]
			},
			{
			"tagName": "recur_daily",
			"childNodes": [{ "nodeValue": "journalier"
}]
			},
			{
			"tagName": "recur_daily_num",
			"childNodes": [{ "nodeValue": "tous les %num% jours"
}]
			},
			{
			"tagName": "recur_daily_weekday",
			"childNodes": [{ "nodeValue": "tous les jours ouvrés"
}]
			},
			{
			"tagName": "recur_weekly",
			"childNodes": [{ "nodeValue": "hebdomadaire"
}]
			},
			{
			"tagName": "recur_weekly_num",
			"childNodes": [{ "nodeValue": "toutes les %num% semaines, le :"
}]
			},
			{
			"tagName": "recur_monthly",
			"childNodes": [{ "nodeValue": "mensuel"
}]
			},
			{
			"tagName": "recur_monthly_num",
			"childNodes": [{ "nodeValue": "jour %num% tous les %num2% mois"
}]
			},
			{
			"tagName": "recur_monthly_date",
			"childNodes": [{ "nodeValue": "les %first% %weekday% tous les %num% mois"
}]
			},
			{
			"tagName": "recur_yearly",
			"childNodes": [{ "nodeValue": "tous les ans"
}]
			},
			{
			"tagName": "recur_yearly_exact",
			"childNodes": [{ "nodeValue": "tous les %day% %month%"
}]
			},
			{
			"tagName": "recur_yearly_rel",
			"childNodes": [{ "nodeValue": "le %first% %weekday% de %month%"
}]
			},
			{
			"tagName": "recur_custom",
			"childNodes": [{ "nodeValue": "personnalisé"
}]
			},
			{
			"tagName": "recur_custom_desc",
			"childNodes": [{ "nodeValue": "Sélectionnez votre série personnalisée de dates dans le petit calendrier de gauche."
}]
			},
			{
			"tagName": "recur_custom_dates",
			"childNodes": [{ "nodeValue": "Dates sélectionnées :"
}]
			},
			{
			"tagName": "recur_end",
			"childNodes": [{ "nodeValue": "Fin de la série :"
}]
			},
			{
			"tagName": "recur_end_after_e",
			"childNodes": [{ "nodeValue": "Arrêter après %num% événements"
}]
			},
			{
			"tagName": "recur_end_after_t",
			"childNodes": [{ "nodeValue": "Terminer après %num% tâche(s)"
}]
			},
			{
			"tagName": "recur_end_by",
			"childNodes": [{ "nodeValue": "par %date%"
}]
			},
			{
			"tagName": "recur_event",
			"childNodes": [{ "nodeValue": "Répéter cet événement :"
}]
			},
			{
			"tagName": "recur_task",
			"childNodes": [{ "nodeValue": "Faire répéter cette tâche :"
}]
			},
			{
			"tagName": "recur_first",
			"childNodes": [{ "nodeValue": "premier/première"
}]
			},
			{
			"tagName": "recur_second",
			"childNodes": [{ "nodeValue": "seconde"
}]
			},
			{
			"tagName": "recur_third",
			"childNodes": [{ "nodeValue": "troisième"
}]
			},
			{
			"tagName": "recur_fourth",
			"childNodes": [{ "nodeValue": "quatrième"
}]
			},
			{
			"tagName": "recur_fifth",
			"childNodes": [{ "nodeValue": "cinquième"
}]
			},
			{
			"tagName": "recur_last",
			"childNodes": [{ "nodeValue": "dernier/dernière"
}]
			}
		],
		"tagName": "lang_table"
		}
	],
	"tagName": "language"
	}
],
"tagName": "languages"
};
;
