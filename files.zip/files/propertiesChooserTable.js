// This file was automatically generated from propertiesChooserTable.soy.
// Please don't edit this file by hand.

goog.provide('jive.rte.table.propertiesChooserTable');

goog.require('soy');
goog.require('soydata');
goog.require('soy.StringBuilder');


jive.rte.table.propertiesChooserTable = function(opt_data, opt_sb) {
  var output = opt_sb || new soy.StringBuilder();
  output.append(soy.$$escapeHtml(jive.i18n._i18n('1b25d9',[])));
  return opt_sb ? '' : output.toString();
};
