// This file was automatically generated from postGuestWroteLabel.soy.
// Please don't edit this file by hand.

goog.provide('jive.i18n.keys.postGuestWroteLabel');

goog.require('soy');
goog.require('soydata');
goog.require('soy.StringBuilder');


jive.i18n.keys.postGuestWroteLabel = function(opt_data, opt_sb) {
  var output = opt_sb || new soy.StringBuilder();
  output.append(soy.$$escapeHtml(jive.i18n._i18n('bb2319',[])));
  return opt_sb ? '' : output.toString();
};
